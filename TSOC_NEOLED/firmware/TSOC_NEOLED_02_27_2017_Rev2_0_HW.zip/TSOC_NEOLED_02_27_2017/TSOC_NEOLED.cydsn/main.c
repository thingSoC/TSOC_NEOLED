/*  ------------------------------------------
 *  TSOC_NEOLED I2C Default Firmware
 *  ------------------------------------------
 *  
 *  The TSOC_NEOLED Board is a programmable LED driver
 *  board for strings of WS2812 Color LEDs. The factory
 *  default programming for the TSOC_NEOLED supports up to
 *  eight (8) strings of 64 LEDs per string (512 LEDs total). 
 *  The TSOC-NEOLED allocates eight(8) bits (one byte) each 
 *  for Red, Green, Blue, and also a Yellow/White channel,
 *  for a 32 bit value per LED, or a total of 2048 bytes.
 *  
 *  The color ordering (byte address) is as follows :
 *  0 - LED0 Green
 *  1 - LED0 Red
 *  2 - LED0 Blue
 *  3 - LED0 Yellow
 *  4 - LED1 Green
 *  5 - LED1 Red
 *  6 - LED1 Blue
 *  7 - LED1 Yellow
 *  
 *  The TSOC_NEOLED looks to the Arduino like an I2C SRAM (memory) 
 *  of 2048 bytes in size. Simply writing to the TSOC_NEOLED like an
 *  I2C memory caues the corresponding LED to light up on the display.
 *  
 *  If the LEDs are RGB only type, then the Yellow channel is not used,
 *  however the addressing remains the same, that is to say, memory is 
 *  reserved for the Yellow/White channel, even if it is not used.
 *  
 *  If the LED string (or matrix panel) is less than 64 LEDs (i.e. string of 30 or 60),
 *  then the extra LED positions are not used, however the addressing remains the same, 
 *  that is to say, memory is reserved for 64 LEDs per string, even if it is less than that.
 *  
 *  The Default I2C address for the TSOC_NEOLED is 8 (Seven bits).
 *  
 *  This simple example lights each color of each LED in sequence,
 *  from low addresses to high addresses.
 *
 * TODO :
 * 1) Add Bootstraploader for UART updates
 *
 * Revision 1.0 : Initial Release
 * Revision 2.0 : Add UART Bootloader for firmware update
 * Revision 3.0 : Add self test mode button
 *
 */
#include <project.h>

extern const uint32 StripLights_CLUT[ ];
extern uint32  StripLights_ledArray[StripLights_ARRAY_ROWS][StripLights_ARRAY_COLS];
#define LEDARRAY_SIZE (StripLights_ARRAY_ROWS * StripLights_ARRAY_COLS *4)
uint32 I2C1_Status;
uint8 self_test_flag = 0;

/************************************************
 *                    Rainbow()
 *
 *  Use the colorwheel section of the color lookup
 *  table to create a rotating rainbow.
 *
 ************************************************/
void Rainbow(uint32 delay)
{
    uint32 startColor = 0;  // Index color in colorwheel
	uint32 ledPosition = 0; // LED position when setting color         
    uint32 color = 0;       // Temp color to set LED
	
    for(;;)
    {   
		// Wait for last update to complete
        while( StripLights_Ready() == 0);  
		
		// Set new start color
        color = startColor;    
		
		// Loop through all LEDs giving each one a different color from the color wheel
        for(ledPosition = 0; ledPosition <= StripLights_ARRAY_COLS; ledPosition++)
        {
            StripLights_Pixel(ledPosition, 0, StripLights_getColor( color ));
            StripLights_Pixel(ledPosition, 1, StripLights_getColor( color ));
            StripLights_Pixel(ledPosition, 2, StripLights_getColor( color ));
            StripLights_Pixel(ledPosition, 3, StripLights_getColor( color ));
            StripLights_Pixel(ledPosition, 4, StripLights_getColor( color ));
            StripLights_Pixel(ledPosition, 5, StripLights_getColor( color ));
            StripLights_Pixel(ledPosition, 6, StripLights_getColor( color ));
            StripLights_Pixel(ledPosition, 7, StripLights_getColor( color ));
            color++;
            if(color >= StripLights_COLOR_WHEEL_SIZE) color = 0;
        }
		
		// Update the LEDs all at once
		StripLights_Trigger(1); 
		
        // Each time through the main loop start with different color
		// Wrap around at end of color wheel
		startColor++;  
        if(startColor >= StripLights_COLOR_WHEEL_SIZE) startColor = 0;
    
        CyDelay(delay);   // Loop delay

	    if(USER_SW_1_Read() == 0) break;  // If SW1 pressed leave
    }	
	// Wait for SW1 to be released then delay a bit for debouncing
	while(USER_SW_1_Read() == 0);         
	CyDelay(50);
}
/************************************************
 *                    OneColor()
 *
 *  Use the colorwheel section of the color lookup
 *  table to write all LEDs the same color.
 *
 ************************************************/
void OneColor(uint32 delay)
{
    uint32 color = 0;  // Index color in colorwheel
	uint32 nextColor = 0;
	uint32 pct = 0;
	uint32 toColor, fromColor, newColor;
	uint32 ledPosition = 0; // LED position when setting color         
	
    for(;;)
    {   
		nextColor = color + 1;
		if(nextColor >= StripLights_COLOR_WHEEL_SIZE) nextColor = 0;
		
		fromColor = StripLights_CLUT[color];
		toColor   = StripLights_CLUT[nextColor];  

		for(pct = 0; pct <= 100; pct += 10)
		{
		    newColor  = (((pct * (toColor & 0x00FF0000)) + ((100-pct) * (fromColor & 0x00FF0000)))/100) & 0x00FF0000;
            newColor |= (((pct * (toColor & 0x0000FF00)) + ((100-pct) * (fromColor & 0x0000FF00)))/100) & 0x0000FF00;
            newColor |= (((pct * (toColor & 0x000000FF)) + ((100-pct) * (fromColor & 0x000000FF)))/100) & 0x000000FF;	
			
			// Wait for last update to complete
			 while( StripLights_Ready() == 0){}; 
			
			// Loop through all LEDs giving each one a different color from the color wheel
	        for(ledPosition = 0; ledPosition <= StripLights_ARRAY_COLS; ledPosition++)
	        {
	            StripLights_Pixel(ledPosition, 0, newColor);
	            StripLights_Pixel(ledPosition, 1, newColor);
	            StripLights_Pixel(ledPosition, 2, newColor);
	            StripLights_Pixel(ledPosition, 3, newColor);
	            StripLights_Pixel(ledPosition, 4, newColor);
	            StripLights_Pixel(ledPosition, 5, newColor);
	            StripLights_Pixel(ledPosition, 6, newColor);
	            StripLights_Pixel(ledPosition, 7, newColor);
	        }
 		
		    // Update the LEDs all at once
	  	    StripLights_Trigger(1); 
			
			CyDelay(delay);   // Loop delay
	    } 
        // Each time through the main loop start with different color
		// Wrap around at end of color wheel
		color++;  
        if(color >= StripLights_COLOR_WHEEL_SIZE) color = 0;

	    if(USER_SW_1_Read() == 0) break;  // If SW1 pressed leave
    }	
	// Wait for SW1 to be released then delay a bit for debouncing
	while(USER_SW_1_Read() == 0);         
	CyDelay(50);
}

/************************************************
 *  SingleLedMultiColor()
 *
 *  Rotate a single LED around the ring changing color.
 *
 ************************************************/
void SingleLedMultiColor(uint32 delay)
{
    uint32 ledPosition = 0;  // On LED position
	uint32 colorIndex = 0;

	// Loop until SW1 pressed
    for(;;)  
    {
		
		// Wait for last update to finish
	    while( StripLights_Ready() == 0);                 
		
		// Clear all LEDs to background color
		StripLights_MemClear(StripLights_BLACK);   
		
		// Set the color of a single LED
	    StripLights_Pixel(ledPosition, 0,  StripLights_getColor( colorIndex ) ); 
	    StripLights_Pixel(ledPosition, 1,  StripLights_getColor( colorIndex ) ); 
	    StripLights_Pixel(ledPosition, 2,  StripLights_getColor( colorIndex ) ); 
	    StripLights_Pixel(ledPosition, 3,  StripLights_getColor( colorIndex ) ); 
	    StripLights_Pixel(ledPosition, 4,  StripLights_getColor( colorIndex ) ); 
	    StripLights_Pixel(ledPosition, 5,  StripLights_getColor( colorIndex ) ); 
	    StripLights_Pixel(ledPosition, 6,  StripLights_getColor( colorIndex ) ); 
	    StripLights_Pixel(ledPosition, 7,  StripLights_getColor( colorIndex ) ); 

		// Trigger update of all LEDs at once
        StripLights_Trigger(1);    
		
		// Loop delay
        CyDelay(delay);    

		// Advance to next position.  If too far, start back at 0
		ledPosition++;  
		if(ledPosition >= StripLights_ARRAY_COLS) ledPosition = 0;
		
		colorIndex++;  
        if(colorIndex >= StripLights_COLOR_WHEEL_SIZE) colorIndex = 0;

		// If SW1 is pressed, leave loop
		if(USER_SW_1_Read() == 0) break; 
    }	
	
	// Wait for button release and delay to debounce switch
	while(USER_SW_1_Read() == 0);   
	CyDelay(50);
}


/************************************************
 *                    SingleLED()
 *
 *  Rotate a single LED around the ring.
 *
 ************************************************/
void SingleLED(uint32 delay)
{
    uint32 ledPosition = 0;  // On LED position

	// Loop until SW1 pressed
    for(;;)  
    {
		// Wait for last update to finish
	    while( StripLights_Ready() == 0);                 
		
		// Clear all LEDs to background color
		StripLights_MemClear(StripLights_BLACK);   
		
		// Set the color of a single LED
	    StripLights_Pixel(ledPosition, 0, StripLights_RED ); 
	    StripLights_Pixel(ledPosition, 1, StripLights_RED ); 
	    StripLights_Pixel(ledPosition, 2, StripLights_RED ); 
	    StripLights_Pixel(ledPosition, 3, StripLights_RED ); 
	    StripLights_Pixel(ledPosition, 4, StripLights_RED ); 
	    StripLights_Pixel(ledPosition, 5, StripLights_RED ); 
	    StripLights_Pixel(ledPosition, 6, StripLights_RED ); 
	    StripLights_Pixel(ledPosition, 7, StripLights_RED ); 

		// Trigger update of all LEDs at once
        StripLights_Trigger(1);    

		
		// Loop delay
        CyDelay(delay);    

		// Advance to next position.  If too far, start back at 0
		ledPosition++;  
		if(ledPosition >= StripLights_ARRAY_COLS) ledPosition = 0;

		// If SW1 is pressed, leave loop
		if(USER_SW_1_Read() == 0) break; 
    }	
	
	// Wait for button release and delay to debounce switch
	while(USER_SW_1_Read() == 0);   
	CyDelay(50);
}

void self_test_mode(void) {
    PWM_1_Start();
    I2C_1_Stop();
    for (;;) {
       Rainbow(20);
       OneColor(20);
       SingleLED(20);
       SingleLedMultiColor(20);
       Rainbow(20);
       SingleLED(20);
       self_test_flag = 0;
       PWM_1_Stop();
       StripLights_MemClear(StripLights_BLACK);
       StripLights_Trigger(1);
       break;
    }
}

CY_ISR_PROTO(TIMER_1_IRQ_Handler);
unsigned long   timer_1_irq_status                   = 0u;
unsigned char   timer_1_irq_flag                     = 0u;
/**
  * @fn         void TIMER_1_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the TIMER_1 Component
  * @param      void
  * @retval     void
  */
CY_ISR(TIMER_1_IRQ_Handler)
{
	/* Read interrupt source registers */
    timer_1_irq_status = TIMER_1_GetInterruptSource();
	/* increment the timer expired flag, which is the  */
	/* number of times the Modbus 3.5 Character Timeout has occurred */
    timer_1_irq_flag++; 
	/* Clear handled interrupt */
	TIMER_1_ClearInterrupt(timer_1_irq_status);
    /* TIMER_1 is typically used as Reset Timer for entering the Bootloader program. */
    Bootloadable_Load();
}

CY_ISR_PROTO(TIMER_2_IRQ_Handler);
unsigned long   timer_2_irq_status                   = 0u;
unsigned char   timer_2_irq_flag                     = 0u;
/**
  * @fn         void TIMER_2_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the TIMER_2 Component
  * @param      void
  * @retval     void
  */
CY_ISR(TIMER_2_IRQ_Handler)
{
	/* Read interrupt source registers */
    timer_2_irq_status = TIMER_2_GetInterruptSource();
	/* increment the timer expired flag, which is the  */
	/* number of times the Modbus 3.5 Character Timeout has occurred */
    timer_2_irq_flag++; 
	/* Clear handled interrupt */
	TIMER_2_ClearInterrupt(timer_2_irq_status);
    /* TIMER_2 is typically used as Mode Timer for entering the selftest mode. */
    self_test_flag = 1;
}

int main()
{
     
      TIMER_1_Start();
      TIMER_1_IRQ_StartEx(TIMER_1_IRQ_Handler);
      /* Clear any pending Interrupts for TIMER_1 */
      TIMER_1_IRQ_ClearPending();

      TIMER_2_Start();
      TIMER_2_IRQ_StartEx(TIMER_2_IRQ_Handler);
      /* Clear any pending Interrupts for TIMER_1 */
      TIMER_2_IRQ_ClearPending();


      /* Initialize StripLights */
      StripLights_Start();  
	
	  // Set dim level 0 = full power, 4 = lowest power
      StripLights_Dim(3); 
	
	  // Clear all memory to black
	  StripLights_MemClear(StripLights_BLACK);

	  // Enable global interrupts, required for StripLights
      CyGlobalIntEnable;  
    
        /* Start the Primary I2C channel */
	    I2C_1_EzI2CSetBuffer1(LEDARRAY_SIZE, LEDARRAY_SIZE, (uint8 *)StripLights_ledArray);
	    I2C_1_Start();
        
	    for(;;) {
          if (self_test_flag) {
            self_test_mode();
          } else {
            I2C1_Status = I2C_1_EzI2CGetActivity();
            if (I2C1_Status == I2C_1_EZI2C_STATUS_WRITE1) {
              StripLights_Trigger(1);
            }
            CyDelay(10);
          }
	    }

      return(-1);
}
/* [] END OF FILE */
