/*******************************************************************************
* File Name: Boot_SW.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Boot_SW_H) /* Pins Boot_SW_H */
#define CY_PINS_Boot_SW_H

#include "cytypes.h"
#include "cyfitter.h"
#include "Boot_SW_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    Boot_SW_Write(uint8 value) ;
void    Boot_SW_SetDriveMode(uint8 mode) ;
uint8   Boot_SW_ReadDataReg(void) ;
uint8   Boot_SW_Read(void) ;
uint8   Boot_SW_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Boot_SW_DRIVE_MODE_BITS        (3)
#define Boot_SW_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - Boot_SW_DRIVE_MODE_BITS))

#define Boot_SW_DM_ALG_HIZ         (0x00u)
#define Boot_SW_DM_DIG_HIZ         (0x01u)
#define Boot_SW_DM_RES_UP          (0x02u)
#define Boot_SW_DM_RES_DWN         (0x03u)
#define Boot_SW_DM_OD_LO           (0x04u)
#define Boot_SW_DM_OD_HI           (0x05u)
#define Boot_SW_DM_STRONG          (0x06u)
#define Boot_SW_DM_RES_UPDWN       (0x07u)

/* Digital Port Constants */
#define Boot_SW_MASK               Boot_SW__MASK
#define Boot_SW_SHIFT              Boot_SW__SHIFT
#define Boot_SW_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Boot_SW_PS                     (* (reg32 *) Boot_SW__PS)
/* Port Configuration */
#define Boot_SW_PC                     (* (reg32 *) Boot_SW__PC)
/* Data Register */
#define Boot_SW_DR                     (* (reg32 *) Boot_SW__DR)
/* Input Buffer Disable Override */
#define Boot_SW_INP_DIS                (* (reg32 *) Boot_SW__PC2)


#if defined(Boot_SW__INTSTAT)  /* Interrupt Registers */

    #define Boot_SW_INTSTAT                (* (reg32 *) Boot_SW__INTSTAT)

#endif /* Interrupt Registers */


/***************************************
* The following code is DEPRECATED and 
* must not be used.
***************************************/

#define Boot_SW_DRIVE_MODE_SHIFT       (0x00u)
#define Boot_SW_DRIVE_MODE_MASK        (0x07u << Boot_SW_DRIVE_MODE_SHIFT)


#endif /* End Pins Boot_SW_H */


/* [] END OF FILE */
