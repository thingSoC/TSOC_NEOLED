/*  ------------------------------------------
 *  TSOC_NEOLED I2C Default Firmware
 *  ------------------------------------------
 *  
 *  The TSOC_NEOLED Board is a programmable LED driver
 *  board for strings of WS2812 Color LEDs. The factory
 *  default programming for the TSOC_NEOLED supports up to
 *  eight (8) strings of 64 LEDs per string (512 LEDs total). 
 *  The TSOC-NEOLED allocates eight(8) bits (one byte) each 
 *  for Red, Green, Blue, and also a Yellow/White channel,
 *  for a 32 bit value per LED, or a total of 2048 bytes.
 *  
 *  The color ordering (byte address) is as follows :
 *  0 - LED0 Green
 *  1 - LED0 Red
 *  2 - LED0 Blue
 *  3 - LED0 Yellow
 *  4 - LED1 Green
 *  5 - LED1 Red
 *  6 - LED1 Blue
 *  7 - LED1 Yellow
 *  
 *  The TSOC_NEOLED looks to the Arduino like an I2C SRAM (memory) 
 *  of 2048 bytes in size. Simply writing to the TSOC_NEOLED like an
 *  I2C memory caues the corresponding LED to light up on the display.
 *  
 *  If the LEDs are RGB only type, then the Yellow channel is not used,
 *  however the addressing remains the same, that is to say, memory is 
 *  reserved for the Yellow/White channel, even if it is not used.
 *  
 *  If the LED string (or matrix panel) is less than 64 LEDs (i.e. string of 30 or 60),
 *  then the extra LED positions are not used, however the addressing remains the same, 
 *  that is to say, memory is reserved for 64 LEDs per string, even if it is less than that.
 *  
 *  The Default I2C address for the TSOC_NEOLED is 8 (Seven bits).
 *  
 *  This simple example lights each color of each LED in sequence,
 *  from low addresses to high addresses.
 *
 * TODO :
 * 1) Add Bootstraploader for UART updates
 *
 * Revison 1.0 : Initial Release
 *
 */

 
#include <project.h>

extern const uint32 StripLights_CLUT[ ];
extern uint32  StripLights_ledArray[StripLights_ARRAY_ROWS][StripLights_ARRAY_COLS];
#define LEDARRAY_SIZE (StripLights_ARRAY_ROWS * StripLights_ARRAY_COLS *4)
uint32 I2C1_Status;

int main()
{
	  /* Start the Primary I2C channel */
	  I2C_1_EzI2CSetBuffer1(LEDARRAY_SIZE, LEDARRAY_SIZE, (uint8 *)StripLights_ledArray);
	  I2C_1_Start();

      /* Initialize StripLights */
      StripLights_Start();  
	
	  // Set dim level 0 = full power, 4 = lowest power
      StripLights_Dim(3); 
	
	  // Clear all memory to black
	  StripLights_MemClear(StripLights_BLACK);

	  // Enable global interrupts, required for StripLights
      CyGlobalIntEnable;  
    
	  for(;;)
	  {
        I2C1_Status = I2C_1_EzI2CGetActivity();
        if (I2C1_Status == I2C_1_EZI2C_STATUS_WRITE1) {
            StripLights_Trigger(1);
        }
        CyDelay(10);
	  }
}
/* [] END OF FILE */
